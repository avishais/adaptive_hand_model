Video attachment for RAL and ICRA submission for paper titled: Learning a state transition model of an underactuated adaptive hand
